Simply build and run the Main line to be asked to enter strings (and then a word) to find out if either is a palindrome!
